/*id, companyName, price, lastUpdatedOn
	>> Where, we have to manually add some records, in the table so that user can see these shares and do transactions for them
*/

package com.amazon.demataccount.model;

public class Share {
	private int id;
	private String companyName;
	private double price;
	private String lastUpdatedOn;

/*	Share Atlas1 = new Share();
	Share Atlas2 = new Share();
	Share Atlas3 = new Share();
	*/
	
	public Share(int id, String companyName, double price, String lastUpdatedOn) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.price = price;
		this.lastUpdatedOn = lastUpdatedOn;
		
	}

	@Override
	public String toString() {
		return "Share [id=" + id + ", companyName=" + companyName + ", price=" + price + ", lastUpdatedOn="
				+ lastUpdatedOn + "]";
	}
	
	
}
