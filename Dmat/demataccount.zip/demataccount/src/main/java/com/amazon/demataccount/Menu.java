package com.amazon.demataccount;
import java.util.Date;
import java.util.Scanner;

import com.amazon.demataccount.controller.AuthenticationService;
import com.amazon.demataccount.model.User;


public class Menu {

	public void showMenu() {
		while true() {
			System.out.println("1: Create A New Demat Account");
        	System.out.println("2: Login to Demat Account");
        	System.out.println("3: Quit");
        	System.out.println("Select an Option");
		}
		 
		 System.out.println("~~~~~~~~~~~~~~~~~"); 
		 System.out.println("Welcome to DEMAT ACCOUNT APP"); 
		 System.out.println("0 : Quit"); 
         System.out.println("1 : Display Demat Account Details"); 

		 System.out.println("2: Deposit Money"); 

		 System.out.println("3: Withdraw Money"); 

		 System.out.println("4: Buy Transaction"); 
		 System.out.println("5: Sell Transaction");
		 System.out.println("6: View Transaction Report");


		
	}
	
}
