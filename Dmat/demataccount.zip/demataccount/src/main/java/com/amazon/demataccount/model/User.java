package com.amazon.demataccount.model;

	/*

	SQL Query for Table

	MySQL:
	create table User(
		id INT PRIMARY KEY AUTO_INCREMENT,
		id VARCHAR(256),
		username VARCHAR(256),
		email VARCHAR(256) NOT NULL UNIQUE,
		password VARCHAR(256),
		address VARCHAR(256),
		department VARCHAR(256),
		type INT NOT NULL,
		createdOn DATETIME DEFAULT CURRENT_TIMESTAMP
	);

	MSSQL:
	create table User(
		id INT IDENTITY(1,1),
		name NVARCHAR(50) not null,
		email NVARCHAR(30) UNIQUE,
		password NVARCHAR(30),
		address NVARCHAR(100),
		department NVARCHAR(30),
		type INT,
		createdOn DATETIME DEFAULT CURRENT_TIMESTAMP,
		PRIMARY KEY(id);
	);

	*/

	public class User {
		
		// Attributes
		public int id;
		public String userName;
		public int accountNumber;
		public String password;
		public double accountBalance;
		public String lastUpdatedOn;
		
		public User() {
			
			
		}
		
		
		
		public User(int id, String userName, int accountNumber, String password, int accountBalance,
				String lastUpdatedOn) {
			super();
			this.id = id;
			this.userName = userName;
			this.accountNumber = accountNumber;
			this.password = password;
			this.accountBalance = accountBalance;
			this.lastUpdatedOn = lastUpdatedOn;
		}



		public void prettyPrint() {
			System.out.println("~~~~~~~~~~~~~~~~~~~~~");
			System.out.println("ID:\t\t"+id);
			System.out.println("UserName:\t\t"+userName);
			System.out.println("AccountNumber:\t\t"+accountNumber);
			System.out.println("Password:\t"+password);
			System.out.println("AccountBalance:\t"+accountBalance);
			System.out.println("LastUpdatedOn:\t"+lastUpdatedOn);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~");
		}



		@Override
		public String toString() {
			return "User [id=" + id + ", userName=" + userName + ", accountNumber=" + accountNumber + ", password="
					+ password + ", accountBalance=" + accountBalance + ", lastUpdatedOn=" + lastUpdatedOn + "]";
		}

		
		}
		
	
