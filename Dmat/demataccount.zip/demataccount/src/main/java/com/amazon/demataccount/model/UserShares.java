/*UserShares
	id, userId, shareId, companyName, shareCount
	*/

package com.amazon.demataccount.model;

public class UserShares {
	private int userId;
	private int shareId;
	private String companyName;
	private int shareCount;
	

}
