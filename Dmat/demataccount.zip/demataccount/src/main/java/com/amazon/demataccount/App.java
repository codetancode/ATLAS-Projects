package com.amazon.demataccount;

import java.util.Date;
import com.amazon.demataccount.model.Transaction;

import java.util.Scanner;

public class App{
    
	private App(){
			
		
        System.out.println( "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" );
        System.out.println( "Welcome to ATLAS DEMAT Account" );
        System.out.println( "~~~~~~~~~~~~~~~~~~~~~~~~~~~`" );
	}
        Scanner scanner = new Scanner(System.in);
    	
    	void showMainMenu() {
  
    	
    		// Initial Menu for the Application
            while(true) 
            
            {
            	System.out.println("1: Create A New D-MAT Account");
            	System.out.println("2: Login to your D-MAT Account");
            	System.out.println("3: Quit");
                System.out.println("Select an Option");
            	
            	int choice = scanner.nextInt();
            	
            	if(choice== 1) {
            		System.out.println("Navigating to Creating New D-MAT Account");
            		//showCreateAccount();
            	} else if(choice == 2 ) {
            		System.out.println("Navigating to User Menu..");
            	showUserMenu();
            	} else if(choice == 3) {
            		System.out.println("Thank You For Using D-MAT Trading Account App");
            	break;
            	}
            	else {
            		System.err.println("Invalid Choice...");
            	}
            }
    	}
          void showUserMenu()  
            {
            	
            	System.out.println("0: Quit");
            	System.out.println("1: Show Demat Account Details");
            	System.out.println("2: Deposit Money");
            	System.out.println("3: Withdraw Money");
            	System.out.println("4: Buy Transaction");
            	System.out.println("5: Sell Transaction");
            	System.out.println("6: View Transaction Report");
            	System.out.println("Select an Option");
            	
            	int choice = scanner.nextInt();
            	switch (choice) {

            	
            	case 0: 
            		System.out.println("Thank You For using ATLAS Demat Account App");
            		break;
            	case 1 :
            		System.out.println("Navigating to Your ATLAS Demat Account Details Dashboard...");
            		// showDematAccountDetails(); 
            		break;
            	case 2 :
            		System.out.println("Navigating To Deposit Money");
           // 		showDepositMoney();
            		break;
            		
            	case 3 :
        		System.out.println("Navigating to Withdraw Money");
        	//	showWithdrawMoney();
            	case 4:
    	     	System.out.println("Navigating to Buy Transaction");
    	     	buy();
      	     	break;
            	case 5 :
	         	System.out.println("Navigating to Sell Transaction");
	//	showSellTransaction();
            	case 6 :
	           	System.out.println("Navigating to Transaction Report");
	           	break;
	//	showTransactionReport();
            	case 7 :
            		System.err.println("Invalid Choice...");
            	}
            	scanner.close();
            }
       //  scanner.close();
            
    	// DEMAT ACCOUNT DETAILS //
    	
    	// void showDematAccountDetails() {
    		
    		// Login Code should come before the Menu becomes Visible to the User
    /*		User user = new User();
    		
    		// An empty scanner.nextLine as we are reading string after int :)
    		scanner.nextLine();
    		
    		System.out.println("Enter Your Email:");
    		user.email = scanner.nextLine();
    		
    		System.out.println("Enter Your Password:");
    	user.password = scanner.nextLine(); */
    		
    		
    			
   /*The account should have the following user details:
a. User name
b. Account number
c. Money in the account (that can be used to buy shares or put into the account
when shares are sold)
d. Share name or ID (to identify the company name)
e. Number of shares (of each company) held
f. Value of each share
    *  			
    */
    			
   /*        	switch (choice) {
    					case 1:
    						
    						break;
    						
    					case 2:
    						
    						break;
    	
    					case 3:
    						
    						break;
    						
    					case 4:
    						
    						break;
    						
    					case 5:
    						
    						break;
    						
    					case 6:
    						System.out.println("Thank You for Using Admin App !!");
    						quit = true;
    						break;
    		
    					default:
    						System.err.println("Invalid Choice...");
    						break;
    				}
    		
    	        	if(quit) {
    	        		break;
    	        	}
    		else 
    			{
    			System.err.println("Invalid Credentials. Please Try Again !!");
    			}
    		*/
    	// DEPOSIT MONEY//
    	        	
            	
    	   void showDepositMoney() {
    	        		
    	        	}
    	   
    	   // WITHDRAW MONEY//
    	   
void showWithdrawMoney() {
	
}


//BUY TRANSACTION//

 void buy(int shareID, double pricePerShare, int shareCount) {
	
	capital -=  s * p;
	transactionCharges = capital * 0.5;
	sttCharges = capital * 0.1;
	accBalance = capital - transactionCharges - sttCharges;
}



//SELL TRANSACTION// 

void showSellTransaction() {
	
}
// TRANSACTION REPORT// 

void showTransactionReport() {
	
} 

            public static void main( String[] args ){
                App app = new App();
                app.showMainMenu();
            }

    	

        
}
