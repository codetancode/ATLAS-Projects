package com.amazon.demataccount;


public class Config {
	//symbolic constants :)
	final double TransactionCharge = 0.5;
	final double SecuritiesTransferTax = 0.1;
	final double MinimumTransactionCharge = 100;
	

	
}

