package com.amazon.demataccount.controller;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Date;
import java.text.SimpleDateFormat;



import com.amazon.demataccount.db.DB;
import com.amazon.demataccount.db.UserDAO;
import com.amazon.demataccount.model.User;

public class AuthenticationService {
	
	private static AuthenticationService service = new AuthenticationService();
	UserDAO dao = new UserDAO();
	SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	Date date = new Date();

	
	// Dummy DataBase in RAM
	LinkedHashMap<Integer, User> users = new LinkedHashMap<Integer, User>();
	
	private AuthenticationService(){
		

		User user = new User();
		user.id = 1234;
		user.userName = "John Watson";
		user.accountNumber = 224466;
		user.password = "admin123";
		user.accountBalance = 10000.00;
		user.lastUpdatedOn = formatter.format(date);
		
		
		
		// Dummy Users in the HashMap :)
		users.put(user.id, user);	
		
		System.out.println("DataBase Details:");
		System.out.println(users);
		
		UserDAO dao = new UserDAO();
		dao.insert(user);
	}
	
	
		public static AuthenticationService getInstance() {
		return service;
	}
	
	public boolean loginUser(User user) {
		
		boolean result = false;
		
		
		Iterator<Integer> itr = users.keySet().iterator();
		while(itr.hasNext()) {
			Integer key = itr.next();
			
			User u = users.get(key);
			// Select * from User where email = '' and password = ''
			if(u.email.equals(user.email) && u.password.equals(user.password)) {
				// user will now point to a new Object i.e. referred by u
				user.name = u.name;
				user.type = u.type; 
				result = true;
				break;
			}
		
		}
		return result;
	}
	
	public boolean loginUser(User user) {
				
		String sql = "SELECT * FROM User WHERE email = '"+user.email+"' AND password = '"+user.password+"'";
		List<User> users = dao.retrieve(sql);
		
		if(users.size() > 0) {
			User u = users.get(0);
			user.name = u.name;
			user.type = u.type;
			return true;
		}
		
		return false; 
	}
	
	public boolean registerUser(User user) {
		//int result = dao.insert(user);
		//return result > 0;
		return dao.insert(user) > 0;
	}
	
}
