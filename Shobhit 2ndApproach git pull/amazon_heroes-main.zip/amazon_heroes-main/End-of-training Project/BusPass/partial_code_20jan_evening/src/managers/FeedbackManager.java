package managers;

public class FeedbackManager {

}
