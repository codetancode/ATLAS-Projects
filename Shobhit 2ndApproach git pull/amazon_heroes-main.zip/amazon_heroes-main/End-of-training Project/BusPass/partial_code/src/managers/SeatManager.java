package managers;

public class SeatManager {

	public static Object getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
