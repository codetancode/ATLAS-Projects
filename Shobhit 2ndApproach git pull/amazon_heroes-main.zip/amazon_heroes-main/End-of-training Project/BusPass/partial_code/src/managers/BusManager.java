package managers;

public class BusManager {

	public static Object getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

}
