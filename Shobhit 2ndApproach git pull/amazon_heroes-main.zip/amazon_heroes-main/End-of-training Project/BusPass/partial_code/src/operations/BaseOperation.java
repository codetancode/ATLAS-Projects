package operations;

public class BaseOperation {

}
