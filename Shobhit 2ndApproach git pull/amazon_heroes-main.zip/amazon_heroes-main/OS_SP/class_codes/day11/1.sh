#!/bin/bash

# 

echo "friday noon"
echo "today is ?"
read day
echo "have a good $day"
