#!/bin/bash

case "$1" in 
	"dosa") echo "masala or rawa-masala?"
		;;
	"pasta") echo "white sauce or red?"
		;&
	"dal rice") echo "yellow dal or makhni?"
		;;
	*) echo "chicken platter"
		;;
esac
