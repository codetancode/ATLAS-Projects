#!/bin/bash

# create/define a function

function greet() {
	echo "good afternoon"
}

greet
