#!/bin/bash

echo "alarm rings"
sleep 10
echo "wake up"
