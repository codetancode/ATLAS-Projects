#!/bin/bash

for (( i=7; i >0; i-- ))
do
	echo "$$ will end in $i seconds"
	sleep 1
done

