#!/bin/bash

read name power

echo "i am $name and my power is $power"
