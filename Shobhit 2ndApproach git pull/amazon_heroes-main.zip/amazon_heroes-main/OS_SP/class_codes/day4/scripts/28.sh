#!/bin/bash

# telling a shell to exit if some command fails
set -e
x=20

echo $x
sleep 2
mnbv
sleep 2
echo "hi"
sleep 2
qwerty
sleep 2
echo "exiting"


