#!/bin/bash

name="pranjal"

echo ${name}gusain

