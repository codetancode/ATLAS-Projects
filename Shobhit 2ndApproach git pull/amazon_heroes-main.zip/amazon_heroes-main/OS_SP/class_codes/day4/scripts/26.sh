#!/bin/bash

echo "bolo tara ra ra"
