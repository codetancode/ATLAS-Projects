#!/bin/bash

for (( i=0; i <= 3; i++ ))
do
	echo "\$i = $i"
done

