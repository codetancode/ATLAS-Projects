#!/bin/bash

#echo $*

for i in $*
#for i in wed thu fri
do
	echo "\$i = $i"
done

