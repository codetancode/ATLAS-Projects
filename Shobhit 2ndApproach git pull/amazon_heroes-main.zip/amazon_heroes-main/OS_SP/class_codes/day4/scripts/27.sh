#!/bin/bash

echo "\$HOME = $HOME"
echo "\$EDITOR = $EDITOR"
