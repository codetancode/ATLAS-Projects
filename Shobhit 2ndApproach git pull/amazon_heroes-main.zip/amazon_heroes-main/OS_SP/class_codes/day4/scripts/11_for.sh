#!/bin/bash

#for (( i=2; i <=16; i=i+2 ))
for i in {2..16..2}
do
	echo "$i"
done

