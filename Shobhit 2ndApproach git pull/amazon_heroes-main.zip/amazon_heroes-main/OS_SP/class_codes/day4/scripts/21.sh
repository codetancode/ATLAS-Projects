#!/bin/bash

echo "will delete temporary files in 5 seconds"
sleep 5
# code for deleting

echo "deleted"
