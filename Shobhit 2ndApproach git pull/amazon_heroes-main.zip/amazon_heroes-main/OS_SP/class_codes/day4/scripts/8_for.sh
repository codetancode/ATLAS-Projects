#!/bin/bash

for i in 1 2 "hello" 4
do
	echo "\$i = $i"
done

