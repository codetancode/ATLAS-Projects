#!/bin/bash

exec firefox
