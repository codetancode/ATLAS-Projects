#include<stdio.h>
#include<unistd.h>

void main()
{
	printf("pid = %d", getpid());
	while(1)
	{
	}
	return;
}
