#include<stdio.h>
#include<unistd.h>

int main()
{
	printf("salaam\n");
	fork();
	printf("sat sri akaal\n");
	printf("jai jinendra\n");
	return 0;
}
