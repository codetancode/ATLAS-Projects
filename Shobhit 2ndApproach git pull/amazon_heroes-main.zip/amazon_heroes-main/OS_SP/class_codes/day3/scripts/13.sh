#!/bin/bash

age=41
age=$(( age + 2))
echo "age is now $age"
