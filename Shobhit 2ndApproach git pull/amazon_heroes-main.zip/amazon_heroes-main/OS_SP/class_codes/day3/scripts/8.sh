#!/bin/bash

age=41
echo "good morning $LOGNAME, you are $age years old"
