#!/bin/bash

read stat

if [ -z $stat ]
then
	echo "size is zero"
else
	echo "we welcome you"
	# logic of your program 
fi

echo "ending the script"
