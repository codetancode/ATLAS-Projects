#!/bin/bash

echo "good morning"
echo "what is your name?"
read name
echo "hello name"
echo "have a good learning Friday"
