#!/bin/bash

stat=/home/nigam/Desktop/captain/day3/scripts/100.sh
if [ -e $stat ]
then
	echo "file exists"
else
	echo "no such file"
	# logic of your program 
fi

echo "ending the script"
