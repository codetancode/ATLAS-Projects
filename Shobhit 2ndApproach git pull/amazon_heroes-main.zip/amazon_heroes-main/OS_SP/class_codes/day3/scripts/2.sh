clear
pwd
ls
abhinav
wc one.txt
