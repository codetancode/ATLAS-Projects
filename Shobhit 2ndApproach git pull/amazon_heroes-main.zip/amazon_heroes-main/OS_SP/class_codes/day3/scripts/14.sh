#!/bin/bash

age=41
age=`expr $age + 2`
echo "age is now $age"
