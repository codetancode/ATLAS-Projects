#!/bin/bash

name="John Doe"
age=41
echo "good morning $name, you are $age years old"
name="jon snow"
echo "hello $name"
echo "have a good learning Friday"
