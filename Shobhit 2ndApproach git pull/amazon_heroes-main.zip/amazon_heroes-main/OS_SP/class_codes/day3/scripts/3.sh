#!/bin/bash

# an example shell script
# author : shobhit
# atlas 3.0 : team captain

ls
abhinav
