#!/bin/bash

# an example shell script
# author : shobhit
# atlas 3.0 : team captain

ls
/home/nigam/Desktop/captain/day3/2.sh
