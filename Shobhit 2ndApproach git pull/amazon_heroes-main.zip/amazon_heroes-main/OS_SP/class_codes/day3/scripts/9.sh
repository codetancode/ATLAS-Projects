#!/bin/bash

# mathematics 

age=30

echo "initial age is $age"
let age=$age+1
echo "incremented age is $age"

