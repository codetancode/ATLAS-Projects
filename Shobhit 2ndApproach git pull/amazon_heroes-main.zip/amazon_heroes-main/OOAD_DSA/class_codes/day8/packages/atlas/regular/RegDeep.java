package com.atlas.regular;

import com.atlas.demo.*;

import com.atlas.demo.in.*;

public class RegDeep {
	public static void main(String args[]) {
		Deep obja = new Deep();
		obja.met_d();
	}
}
