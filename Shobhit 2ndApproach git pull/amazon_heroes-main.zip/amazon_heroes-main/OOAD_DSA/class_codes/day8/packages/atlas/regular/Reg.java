package com.atlas.regular;

import com.atlas.demo.*;

public class Reg {
	public static void main(String args[]) {
		One obja = new One();
		obja.met_a();
		obja.met_b();
	}
}
