// unhandled exception

class One {
  public static void main(String[] args) {
    String varx = null; 
    System.out.println("length is " + varx.length());
  }
}