class AutoPilotFacade{
  AirBusAltitudeMonitor objam;
  AirBusFuelMonitor objfm;
  AirBusNavigationSystem objns;
  AirBusTemperatureMonitor objmt;
  AirBusPressureMonitor objpm;
  AirBusEngineController objec;

  AutoPilotFacade(  AirBusAltitudeMonitor objam,
  AirBusFuelMonitor objfm,AirBusNavigationSystem objns,
  AirBusTemperatureMonitor objmt,AirBusPressureMonitor objpm,
  AirBusEngine controller objec){
    
  }
  public void putOnAutoPilot(){
    // complex code
    
  }
  public void putOffAutoPilot(){
    
  }
  
  
}