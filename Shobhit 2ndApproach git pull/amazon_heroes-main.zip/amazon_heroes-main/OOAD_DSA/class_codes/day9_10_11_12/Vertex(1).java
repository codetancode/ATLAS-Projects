package graphs;

public class Vertex {

		char label;
	   Boolean visited;
}
