class StringSeven {
  public static void main(String[] args) {

// String literals pool 
    
    String stra = "atlas";
    stra = "amazon";
    System.out.println("stra[1] = " + stra[1]);
    
  }
}