public class One{
	public static void main(String[] args){
		int varx = 100;
	
	}
}
