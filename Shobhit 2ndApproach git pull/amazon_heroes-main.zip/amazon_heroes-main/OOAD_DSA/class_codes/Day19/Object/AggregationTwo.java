class AggregationTwo {
  public static void main(String[] args) {
    System.out.println("Hello world!");
  }
}

class Learner{
  String name;
  List<Trainer> trainers;
}

class Trainer {
  String name;
}

class Module{
  String name;
  List<Trainer> trainers;
}

// whole-part
// a-part-of
// has-A 
