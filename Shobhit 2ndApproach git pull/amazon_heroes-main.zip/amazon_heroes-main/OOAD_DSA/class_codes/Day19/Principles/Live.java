public class Live{
  EatFood ef = new EatFood();
  CookFood cf = new CookFood();
  CleanKitchen ck = new CleanKitchen();
}

class EatFood{
  //
}
class CookFood{
  
}

class CleanKitchen{
  
}